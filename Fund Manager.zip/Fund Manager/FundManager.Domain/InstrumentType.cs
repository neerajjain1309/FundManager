﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using FundManager.Domain.Interfaces;

namespace FundManager.Domain
{
    public enum InstrumentType
    {
        Equity,
        Bond,
        All
    }

}
