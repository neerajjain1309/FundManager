namespace FundManager.Domain
{
    public static class RegionNames
    {
        public const string TopRegion = "TopRegion";
        public const string MainRegion = "MainRegion";
        public const string SummaryRegion = "SummaryRegion";
    }
}